/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package ManagerSystem;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner; // Import the Scanner class to read text files

/**
 *
 * @author mexawo3tebi
 */
public class Main {
    public static ArrayList<Person> employee_database = new ArrayList<>();

    public static void main(String[] args) {
        boolean condition = readFile();
        if (condition){
            System.out.print("File employees.txt Loaded  Successefly "+employee_database.size());

        }
        else{
            System.out.print("File employees.txt not found ..");
            System.exit(0);
        }
        int choice = 0;
        String name;
        String password;
        
          Scanner x = new Scanner(System.in);
            System.out.print("\n---- Employee Login Form ----\n");
            System.out.print("Enter your Name :");
            name = x.next();
            System.out.print("\nEnter your Password :");
            password = x.next();
        int index_of = login_system(name,password);
        if (index_of == -1){
          System.out.print("\nUsername or password is wrong !");

        }
        else{
            
            
        
        Person Personal = employee_database.get(index_of);
        
        if (Personal instanceof HR ){
            do{
                HR hr = (HR) Personal;
                       
            System.out.print("\n[1] -  search & display employe  :");
            System.out.print("\n[2] - Stastical report of departement or Job name:");
            System.out.print("\n[3] - remove employee");
            System.out.print("\n[4] - edit_employe  :");
            System.out.print("\n[5] - display employees (same job or departement)  :");
            System.out.print("\n[0] - Exit");
            System.out.print("\n\nEnter choice number ("+hr.getName()+"):");
 
            choice = x.nextInt();
            
            
            switch (choice){
                case 1:{
                    System.out.print("\nEnter Name:");
                    name = x.next();
                    hr.Search_Display(employee_database,name);
                    break;
                    
                }
                
                    
                case 2:{
                    
                    hr.get_average(employee_database);
                    break;
                    
                }
                 
                case 3:{
                    System.out.print("\nEnter Name:");

                    name = x.next();
                    
                    boolean results = hr.Remove_employee(employee_database, name);
                    if (results){
                        System.out.print("\nSuccessufly delete it ");
                        SaveAllEdit();

                    }
                    else{
                       System.out.print("\nNot Found");

                    }
                }
                 
                case 4:{
                    //edit_employee
                    System.out.print("\nEnter Name:");

                    name = x.next();
                    for (Person worker : employee_database) {
                        if(worker.getName().equals(name)){
                            hr.edit_employee(worker);
                            SaveAllEdit();
                            break;

                        }
                    }
                    break;
                    
                }
                 
                    
                case 5:{
                    hr.display_departement(employee_database);
                    break;
                    
                }
                
     
   
                 
            }
            }while (choice !=0);

                    
        }else if (Personal instanceof Employee ) {
            Employee my_employee = (Employee) Personal;

            do{

            System.out.print("\n[1] - Edit Info :");
            System.out.print("\n[2] - Display Info :");
            System.out.print("\n[0] - Exit");
            System.out.print("\n\nEnter choice number ("+my_employee.getName()+"):");

            choice = x.nextInt();
            switch (choice){
                case 1:{
                    
                    my_employee.edit_info(employee_database,my_employee.getName());
                    SaveAllEdit();
                    break;
                    
                }
                
                case 2:{
                    my_employee.Display_info(my_employee);
                    
                    break;
                }
            }
            }while (choice !=0);

            
                    
        }

        

        }  
      
        

    }

   public static boolean readFile(){
        boolean found_file = false;

       try{
            String current = System.getProperty("user.dir");

            FileInputStream fileInputStream = new FileInputStream(current + "/src/main/java/ManagerSystem/employees.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream));
            found_file = true;
            String lines;
            while((lines = reader.readLine()) != null){
                String[] tokens = lines.split(" ");

            
                
                if (tokens[2].equals("HR")){
                    double salary = Double.parseDouble(tokens[4]);  
                    int user_id = Integer.parseInt(tokens[5]);

                    Person Hr_element = new HR(tokens[0],tokens[1],tokens[2],tokens[3],tokens[6],salary,user_id);
                    employee_database.add(Hr_element);
                    
                }
                
                else{
                    double salary = Double.parseDouble(tokens[4]);  
                    int user_id = Integer.parseInt(tokens[5]);

                    Person Employee_elemnt = new Employee(tokens[0],tokens[1],tokens[2],tokens[3],tokens[6],salary,user_id);
                    employee_database.add(Employee_elemnt);

                }
               // employee_database.add();
            }
            fileInputStream.close();

        }catch (Exception ex){
            found_file = false;
            
   ex.printStackTrace();
        }
       
       return found_file;


    }
    static int login_system(String name,String password){

       for (int i = 0 ; i < employee_database.size() ; i++){
           

           
           
           if (employee_database.get(i).getName().equals(name) && employee_database.get(i).getPassword().equals(password)){
                    return i;
                }



       }

       System.out.println("didnt find");
                    return -1;
                    
       
       
    }
        
      

      public static void SaveAllEdit(){
         String current = System.getProperty("user.dir");

       try {
         FileWriter myWriter = new FileWriter(current + "/src/main/java/ManagerSystem/employees.txt");
//hatim khobar cs A 10000 1 411

           for (Person obj : employee_database) {
               String info = obj.getName()+" "+obj.getAddress()+" "+obj.getJob_title()+" "+obj.getDepartement()+" "+obj.getSalary()+" "+obj.getUser_id()+" "+obj.getPassword();
                 myWriter.write(info+"\n");
       
         }
         myWriter.close();
         
         } catch (IOException e) {
         System.out.println("An error occurred.");
         e.printStackTrace();
       }
    }
      
      
}
