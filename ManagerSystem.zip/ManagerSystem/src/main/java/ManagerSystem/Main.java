/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package ManagerSystem;

 import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner; // Import the Scanner class to read text files

/**
 *
 * @author mexawo3tebi
 */
public class Main {
    public static  final ArrayList<Person> employee_database = new ArrayList<>();

    public static void main(String[] args) {
        boolean condition = readFile();
        if (condition){
            System.out.print("File employees.txt Loaded  Successefly .");

        }
        else{
            System.out.print("File employees.txt not found ..");
            
        }
        int choice = 0;
        String name;
        String password;
        
          Scanner x = new Scanner(System.in);
            System.out.print("---- Employee Login Form ----\n");
            System.out.print("Enter your Name :");
            name = x.next();
            System.out.print("\nEnter your Password :");
            password = x.next();
        int index_of = login_system(name,password);
        if (index_of == -1){
          System.out.print("\nUsername or password is wrong !");

        }
        else{
            
            
        
        Person employe = employee_database.get(index_of);
        
        if (employe instanceof HR ){
            do{
                HR hr = (HR) employe;
                       
            System.out.print("\n[1] -  search & display employe  :");
            System.out.print("\n[2] - get average of departmenet(salary) :");
            System.out.print("\n[3] - remove employee");
            System.out.print("\n[4] - edit_employe  :");
            System.out.print("\n[5] - display_departement  :");
            System.out.print("\n[6] -  sort departement ");
            System.out.print("\n[0] - Exit");
            
 
            choice = x.nextInt();
            
            
            switch (choice){
                case 1:{
                    name = x.next();
                    
                    hr.Search_Display(employee_database,name);
                    
                }
                
                    
                case 2:
                    
                 
                case 3:
                    
                 
                case 4:
                 
                    
                case 5:
                
                    
                case 6:
                    
                 
            }
            }while (choice !=0);

                    
        }else {
         
            do{

            System.out.print("\n[1] - Edit Info :");
            System.out.print("\n[2] - Display Info :");
            System.out.print("\n[0] - Exit");
            choice = x.nextInt();

            }while (choice !=0);

            
                    
        }

        

        }  
      
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        int user_id;
        
       // Employee [] worker = new Employee[100];
        //HR [] hr_manager = new HR[100];
        
        //System.out.print("Loading HR - Employees\n");
        //boolean is_load_hr =loadHr(hr_manager);
        //boolean is_load_employee = loadEmployee(worker);
        //if (is_load_hr && is_load_employee)
        //worker[0] = new Employee("hatim","khobar","CS","A",1000,1);
        //hr_manager[0] = new HR("faisel","khobar","HR","HR",1000,2);
        
        
        //System.out.print(worker[0].toString());
        

        
        // String name, String address, String job_title, String departement, double salary;
        
        

    }
    public static boolean readFile(){
        String current = System.getProperty("user.dir");
        System.out.print(current+"\n");
        try(FileInputStream fileInputStream = new FileInputStream(current + "/employees.txt")){
            BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream));
            String lines;

            while((lines = reader.readLine()) != null){
                System.out.print(lines);
            }
            fileInputStream.close();

        }catch (Exception ex){
   ex.printStackTrace();
        return false;

        }
        return true;

    }
   public static boolean readFile1(){
            boolean found_file = false;

       try{
            
            FileInputStream fileInputStream = new FileInputStream("employees.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream));
            found_file = true;
            String lines;
            while((lines = reader.readLine()) != null){
                String[] tokens = lines.split(" ");
                if (tokens[2].equals("HR")){
                    double salary = Double.parseDouble(tokens[4]);  
                    int user_id = Integer.parseInt(tokens[5]);

                    Person Hr_element = new HR(tokens[0],tokens[1],tokens[2],tokens[3],tokens[6],salary,user_id);
                    employee_database.add(Hr_element);
                    
                }
                
                else{
                    double salary = Double.parseDouble(tokens[4]);  
                    int user_id = Integer.parseInt(tokens[5]);

                    Person Employee_elemnt = new Employee(tokens[0],tokens[1],tokens[2],tokens[3],tokens[6],salary,user_id);
                    employee_database.add(Employee_elemnt);

                }
               // employee_database.add();
            }
            fileInputStream.close();

        }catch (Exception ex){
            found_file = false;
            
   ex.printStackTrace();
        }
       
       return found_file;


    }
    static int login_system(String name,String password){

       for (int i = 0 ; i < employee_database.size() ; i++){
           

           System.out.println(employee_database.get(i).getName());
           
           
           if (employee_database.get(i).getName().equals(name) && employee_database.get(i).getPassword().equals(password)){
                    return i;
                }



       }
                  System.out.println(employee_database.get(1).getName());

       System.out.println("didnt find");
                    return -1;
                    
       
       
    }
        
      

  
}
