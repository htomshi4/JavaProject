/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManagerSystem;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author mexawo3tebi
 */
public class Employee extends Person {

    public Employee(String name, String address, String job_title, String departement, String password, double salary, int user_id) {
        super(name, address, job_title, departement, password, salary, user_id);
    }

    public Employee() {
    }

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setUser_id(int user_id) {
        super.setUser_id(user_id); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setSalary(double salary) {
        super.setSalary(salary); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setPassword(String password) {
        super.setPassword(password); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setDepartement(String departement) {
        super.setDepartement(departement); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setJob_title(String job_title) {
        super.setJob_title(job_title); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setAddress(String address) {
        super.setAddress(address); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setName(String name) {
        super.setName(name); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int getUser_id() {
        return super.getUser_id(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public double getSalary() {
        return super.getSalary(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getPassword() {
        return super.getPassword(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getDepartement() {
        return super.getDepartement(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getJob_title() {
        return super.getJob_title(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getAddress() {
        return super.getAddress(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getName() {
        return super.getName(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    public static void  edit_info(ArrayList<Person> employee_database,String name){
        
        for (Person obj : employee_database) {
            if(obj.getName().equals(name)){
System.out.println("- Edit Dashboard -");
         System.out.println("[1] For Name :");
         System.out.println("[2] For Address :");
         System.out.println("[3] For Department :");
         System.out.println("[4] For Job Title :");
         System.out.println("[5] For Salary :");
         System.out.println("[6] For Password :");

          System.out.println("Choice:");
          Scanner x = new Scanner(System.in);
          int choice = x.nextInt();
          String value;
          
           System.out.println("New Value:");
           
          switch (choice){
              
              case 1:{
                  value = x.next();
                  
                  obj.setName(value);
                  break;
                  
              }
              case 2:{
                 value = x.next();

                  obj.setAddress(value);
                  break;
              }
              case 3:{
                 value = x.next();

                  obj.setDepartement(value);
                  
                          break;
                          
             }
              case 4:{
                 value = x.next();

                  obj.setJob_title(value);
                  break;
              }
              case 5:{
                  int salary = x.nextInt();
                  obj.setSalary(salary);
                  break;
              }
        
                   case 6:{
                 value = x.next();

                  obj.setPassword(value);
                  break;
              }
          }
          
                
            }
        }
         

    }
    
    
    public static void  Display_info(Employee obj){
        System.out.println(obj.toString());
    
    }
}
