/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManagerSystem;

/**
 *
 * @author mexawo3tebi
 */
class Person {

    private String name,address,job_title,departement,password;
    private double salary;
    private int user_id;

    public Person(String name, String address, String job_title, String departement, String password, double salary, int user_id) {
        this.name = name;
        this.address = address;
        this.job_title = job_title;
        this.departement = departement;
        this.password = password;
        this.salary = salary;
        this.user_id = user_id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getJob_title() {
        return job_title;
    }

    public String getDepartement() {
        return departement;
    }

    public String getPassword() {
        return password;
    }

    public double getSalary() {
        return salary;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setJob_title(String job_title) {
        this.job_title = job_title;
    }

    public void setDepartement(String departement) {
        this.departement = departement;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Person{");
        sb.append("name=").append(name);
        sb.append(", address=").append(address);
        sb.append(", job_title=").append(job_title);
        sb.append(", departement=").append(departement);
        sb.append(", password=").append(password);
        sb.append(", salary=").append(salary);
        sb.append(", user_id=").append(user_id);
        sb.append('}');
        return sb.toString();
    }






  
    
    Person(){
        
    }

    
}
