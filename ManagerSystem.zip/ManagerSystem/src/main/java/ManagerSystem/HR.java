/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManagerSystem;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors
import java.io.OutputStreamWriter;
import java.util.Collections;

/**
 *
 * @author mexawo3tebi
 */
public class HR extends Person {

    public HR(String name, String address, String job_title, String departement, String password, double salary, int user_id) {
        super(name, address, job_title, departement, password, salary, user_id);
    }

    public HR() {
    }

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setUser_id(int user_id) {
        super.setUser_id(user_id); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setSalary(double salary) {
        super.setSalary(salary); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setPassword(String password) {
        super.setPassword(password); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setDepartement(String departement) {
        super.setDepartement(departement); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setJob_title(String job_title) {
        super.setJob_title(job_title); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setAddress(String address) {
        super.setAddress(address); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setName(String name) {
        super.setName(name); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int getUser_id() {
        return super.getUser_id(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public double getSalary() {
        return super.getSalary(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getPassword() {
        return super.getPassword(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getDepartement() {
        return super.getDepartement(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getJob_title() {
        return super.getJob_title(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getAddress() {
        return super.getAddress(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getName() {
        return super.getName(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
 public void get_average(ArrayList<Person> employee_database){

        double Sum=0;
        double Avg = 0.0;
        int counter =0 ;
        int choice =0;
        Scanner x = new Scanner(System.in);
        String value;
        
        System.out.println("[1] Average by Job name - [2] Average by departement name");
        choice = x.nextInt();
        System.out.println("Value :");
        value = x.next();
        if (choice == 2){
        for(int i=0; i<employee_database.size(); i++){
            Person employee = employee_database.get(i);
            if (employee.getDepartement().equals(value)){
                Sum+= employee.getSalary();
                counter+=1;
                
                
                
            }
        }      
                Avg= Sum/counter;
        System.out.println("For ("+value+")"+" we Have :"+counter+" Employe\nand average of salary is :"+Avg);

        
        }

        else if (choice == 1){
                    for(int i=0; i<employee_database.size(); i++){
            Person employee = employee_database.get(i);
            if (employee.getJob_title().equals(value)){
                Sum+= employee.getSalary();
                counter+=1;
                
                
                
            }
        }
                    
        Avg= Sum/counter;
        System.out.println("For ("+value+")"+" we Have :"+counter+" Employe\nand average of salary is :"+Avg);
                    
        }

        
    }
    public static void Search_Display(ArrayList<Person> employee_database,String name)
    {
        for (Person worker : employee_database) {
            if(worker.getName().equals(name)){
                System.out.print( worker.toString()+"\n");
                return;
                
            }
        }
        System.out.print("Search Results 0\n");

    }
    public static void display_departement(ArrayList<Person> employee_database){

        int choice =0;
        int counter = 0 ;
        
        Scanner x = new Scanner(System.in);
        String value;
        String current = System.getProperty("user.dir");

        System.out.println("[1] Display by Job name - [2] Display by departement name");
        choice = x.nextInt();
        System.out.println("Value :");
        value = x.next();




         
         
       try {
         FileWriter myWriter = new FileWriter(current + "/src/main/java/ManagerSystem/Display_results.txt");

  if (choice == 2){
        for(int i=0; i<employee_database.size(); i++){
            Person employee = employee_database.get(i);
            if (employee.getDepartement().equals(value)){
                
                System.out.println(employee.toString());
                counter+=1;
                
         myWriter.write(employee.toString()+"\n");

            }
        }      

        
        }

        else if (choice == 1){
                    for(int i=0; i<employee_database.size(); i++){
            Person employee = employee_database.get(i);
            if (employee.getJob_title().equals(value)){
                
                System.out.println(employee.toString());
         myWriter.write(employee.toString()+"\n");

                counter+=1;
                
            }
            
        }
       }

       
             
         
         
         
         
         
                  myWriter.write("Search Results :"+counter+"\n");

                  myWriter.close();

         } catch (IOException e) {
         System.out.println("An error occurred.");
         e.printStackTrace();
       }
       

      
      

        
        
        
    }

    public static boolean Remove_employee(ArrayList<Person> employee_database,String name){
        
        
        for (Person worker : employee_database) {
            if(worker.getName().equals(name)){
                employee_database.remove(worker);
                return true;
                
            }
        }
        return false;
    }
    public static void add_employee(ArrayList<Person> employee_database){
        Scanner input= new Scanner(System.in);

     String name,address,job_title,departement,password;
     double salary;
     int user_id;
        System.out.println("- Add Employee -");
        System.out.println("[1] Enter Name");
        name = input.next();
        System.out.println("[2] Enter Address");
        address = input.next();
        System.out.println("[3] Enter Department");
        departement = input.next();
        System.out.println("[4] Enter Job Title");
        job_title = input.next();
        System.out.println("[5] Enter Salary");
        salary = input.nextInt();
        System.out.println("[6] Enter Password");
        password = input.next();
        user_id = employee_database.size()+1;
       
        //    public Person(String name, String address, String job_title, String departement, String password, double salary, int user_id) {

        if ("HR".equals(job_title)){
            HR hr = new HR(name,address,job_title,departement,password,salary,user_id);
            employee_database.add(hr);
        }
        else{
            Employee emp = new Employee(name,address,job_title,departement,password,salary,user_id);
            employee_database.add(emp);

        }
        
        
    }

    
    public void edit_employee (Person s){
        
        Scanner input= new Scanner(System.in);
        
        System.out.println("- Edit Dashboard -");
        System.out.println("[1] Edit Name");
        System.out.println("[2] Edit Address");
        System.out.println("[3] Edit Department");
        System.out.println("[4] Edit Job Title");
        System.out.println("[5] Edit Salary");
        System.out.print("Choice:");
        
        int Choice=input.nextInt();
        
        switch(Choice){
            case 1:
                System.out.println("Enter New Name: ");
                s.setName(input.next());
                break;
                
            case 2:
                System.out.println("Enter New Address: ");
                s.setAddress(input.next());
                break;
                
            case 3:
                System.out.println("Enter New Department: ");
                s.setAddress(input.next());
                break;
                
            case 4:
                System.out.println("Enter New Job Title: ");
                s.setAddress(input.next());
                break;
                
            case 5:
                System.out.println("Enter New Salary: ");
                s.setAddress(input.next());
                break;
                
            default:
                System.out.println("Invalid choice!");
                break;
                
        }
    }
 
 
}
